/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package violaobuilder;

/**
 *
 * @author Jéssica Ferreira
 */
public class DozeCordasBuilder extends ViolaoBuilder {

    @Override
    public void buildPreco() {
        violao.preco = 600;
    }

    @Override
    public void buildCor() {
        violao.cor = "Marron";
    }

    @Override
    public void buildtipoTarraxa() {
        violao.tipoTarraxa = "Cromada";
    }

    @Override
    public void buildtipoCorda() {
        violao.tipoCorda = "Nylon";
    }

    @Override
    public void buildtamBraco() {
        violao.tamBraco = 60;
    }

    @Override
    public void buildmatCorpo() {
        violao.matCorpo = "Doze Cordas\nO violão 12 cordas traz o dobro de cordas do que o clássico.\nEssas são agrupadas em duplas (metade delas afinadas com uma oitava acima)";
    }

    
}
