/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package violaobuilder;

/**
 *
 * @author Jéssica Ferreira
 */
public class FletBuilder extends ViolaoBuilder {

    @Override
    public void buildPreco() {
        violao.preco = 400;
    }

    @Override
    public void buildCor() {
        violao.cor = "Vermelho";
    }

    @Override
    public void buildtipoTarraxa() {
        violao.tipoTarraxa = "Cromada";
    }

    @Override
    public void buildtipoCorda() {
        violao.tipoCorda = "Nylon";
    }

    @Override
    public void buildtamBraco() {
        violao.tamBraco = 55;
    }

    @Override
    public void buildmatCorpo() {
        violao.matCorpo = "Flet\nA palavra Flat, do Inglês, pode significar “plano” ou “liso”.\nÉ justamente essa a principal característica desse tipo de violão:\nSua caixa acústica é bastante fina! ";
    }

    
}
