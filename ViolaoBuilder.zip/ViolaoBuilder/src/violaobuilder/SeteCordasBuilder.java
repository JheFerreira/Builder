/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package violaobuilder;

/**
 *
 * @author Jéssica Ferreira
 */
public class SeteCordasBuilder extends ViolaoBuilder {

    @Override
    public void buildPreco() {
        violao.preco = 150;
    }

    @Override
    public void buildCor() {
        violao.cor = "Preto";
    }

    @Override
    public void buildtipoTarraxa() {
        violao.tipoTarraxa = "Cromada";
    }

    @Override
    public void buildtipoCorda() {
        violao.tipoCorda = "Nylon";
    }

    @Override
    public void buildtamBraco() {
        violao.tamBraco = 50;
    }

    @Override
    public void buildmatCorpo() {
        violao.matCorpo = "Sete Cordas\nConhecido como o violão brasileiro, já que é indicado para acompanhar gêneros como o choro e o samba.\nEsse tipo de violão não apresenta diferenças na sua estrutura quando comparado ao violão clássico.";
    }


}
