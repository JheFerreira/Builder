/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package violaobuilder;

/**
 *
 * @author Jéssica Ferreira
 */
public class FolkBuilder extends ViolaoBuilder {

    @Override
    public void buildPreco() {
        violao.preco = 300;
    }

    @Override
    public void buildCor() {
        violao.cor = "Marron";
    }

    @Override
    public void buildtipoTarraxa() {
        violao.tipoTarraxa = "Cromada";
    }

    @Override
    public void buildtipoCorda() {
        violao.tipoCorda = "Aço";
    }

    @Override
    public void buildtamBraco() {
        violao.tamBraco = 60;
    }

    @Override
    public void buildmatCorpo() {
        violao.matCorpo = "Folk\nCom o corpo maior e mais “acinturado”, os violões do tipo folk também são bastante populares entre os músicos\nEsse tipo de violão é o mais indicado para gêneros como Pop e Rock, já que gera um som mais encorpado, com timbre diferenciado.";
    }
    
}
