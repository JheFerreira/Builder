/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package violaobuilder;

/**
 *
 * @author Jéssica Ferreira
 */
public class ClassicoBuilder extends ViolaoBuilder {

    @Override
    public void buildPreco() {
        violao.preco = 100;
    }

    @Override
    public void buildCor() {
        violao.cor = "Marron";
    }

    @Override
    public void buildtipoTarraxa() {
        violao.tipoTarraxa = "Cromada";
    }

    @Override
    public void buildtipoCorda() {
        violao.tipoCorda = "Nylon";
    }

    @Override
    public void buildtamBraco() {
        violao.tamBraco = 50;
    }

    @Override
    public void buildmatCorpo() {
        violao.matCorpo = "Classico\nO violão clássico é um modelo acústico e funciona com seis cordas ";
    }

  
 

    
}
