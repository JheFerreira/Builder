/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package violaobuilder;

/**
 *
 * @author Jéssica Ferreira
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Distribuidora distribuidora = new Distribuidora(
	            new ClassicoBuilder());
                    
	 
	    distribuidora.construirViolao();
	    ViolaoProduto violao = distribuidora.getViolao();
	    System.out.println("Violao:" + violao.matCorpo+ "\nTamanho do braço em cm: " + violao.tamBraco 
	            + "\nTipo de corda: " + violao.tipoCorda + "\nTipo de Tarraxa: "
	            + violao.tipoTarraxa + "\nValor: " + violao.preco + "\nCor do violao:" + violao.cor);
	 
	    System.out.println();
            
            
            distribuidora = new Distribuidora(new JumboBuilder());
            distribuidora.construirViolao();
            violao= distribuidora.getViolao();
                System.out.println("Violao:" + violao.matCorpo+ "\nTamanho do braço em cm: " + violao.tamBraco 
                        + "\nTipo de corda: " + violao.tipoCorda + "\nTipo de Tarraxa: "
                        + violao.tipoTarraxa + "\nValor em R$: " + violao.preco + "\nCor do violao:" + violao.cor);

                System.out.println();

            distribuidora = new Distribuidora(new FletBuilder());
            distribuidora.construirViolao();
            violao= distribuidora.getViolao();
                System.out.println("Violao:" + violao.matCorpo+ "\nTamanho do braço em cm: " + violao.tamBraco 
                        + "\nTipo de corda: " + violao.tipoCorda + "\nTipo de Tarraxa: "
                        + violao.tipoTarraxa + "\nValor em R$: " + violao.preco + "\nCor do violao:" + violao.cor);

                System.out.println();    

            distribuidora = new Distribuidora(new FolkBuilder());
            distribuidora.construirViolao();
            violao= distribuidora.getViolao();
                System.out.println("Violao:" + violao.matCorpo+ "\nTamanho do braço em cm: " + violao.tamBraco 
                        + "\nTipo de corda: " + violao.tipoCorda + "\nTipo de Tarraxa: "
                        + violao.tipoTarraxa + "\nValor em R$: " + violao.preco + "\nCor do violao:" + violao.cor);

                System.out.println();  


            
	 
            distribuidora = new Distribuidora(new SeteCordasBuilder());
            distribuidora.construirViolao();
            violao= distribuidora.getViolao();
                System.out.println("Violao:" + violao.matCorpo+ "\nTamanho do braço em cm: " + violao.tamBraco 
	            + "\nTipo de corda: " + violao.tipoCorda + "\nTipo de Tarraxa: "
	            + violao.tipoTarraxa + "\nValor em R$: " + violao.preco + "\nCor do violao:" + violao.cor);
	 
	    System.out.println(); 
            
            distribuidora = new Distribuidora(new DozeCordasBuilder());
            distribuidora.construirViolao();
            violao= distribuidora.getViolao();
                System.out.println("Violao:" + violao.matCorpo+ "\nTamanho do braço em cm: " + violao.tamBraco 
	            + "\nTipo de corda: " + violao.tipoCorda + "\nTipo de Tarraxa: "
	            + violao.tipoTarraxa + "\nValor em R$: " + violao.preco + "\nCor do violao:" + violao.cor);
	 
	    System.out.println();  
            
            distribuidora = new Distribuidora(new ZeroBuilder());
            distribuidora.construirViolao();
            violao= distribuidora.getViolao();
                System.out.println("Violao:" + violao.matCorpo+ "\nTamanho do braço em cm: " + violao.tamBraco 
	            + "\nTipo de corda: " + violao.tipoCorda + "\nTipo de Tarraxa: "
	            + violao.tipoTarraxa + "\nValor em R$: " + violao.preco + "\nCor do violao:" + violao.cor);
	 
	    System.out.println();  
            
            distribuidora = new Distribuidora(new DuploZeroBuilder());
            distribuidora.construirViolao();
            violao= distribuidora.getViolao();
                System.out.println("Violao:" + violao.matCorpo+ "\nTamanho do braço em cm: " + violao.tamBraco 
	            + "\nTipo de corda: " + violao.tipoCorda + "\nTipo de Tarraxa: "
	            + violao.tipoTarraxa + "\nValor em R$: " + violao.preco + "\nCor do violao:" + violao.cor);
	 
	    System.out.println();
            
            distribuidora = new Distribuidora(new TriploZeroBuilder());
            distribuidora.construirViolao();
            violao= distribuidora.getViolao();
                System.out.println("Violao:" + violao.matCorpo+ "\nTamanho do braço em cm: " + violao.tamBraco 
	            + "\nTipo de corda: " + violao.tipoCorda + "\nTipo de Tarraxa: "
	            + violao.tipoTarraxa + "\nValor em R$: " + violao.preco + "\nCor do violao:" + violao.cor);
	 
	    System.out.println();  
	  
    }
    
}
