/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package violaobuilder;

/**
 *
 * @author Jéssica Ferreira
 */
public class JumboBuilder extends ViolaoBuilder {

    @Override
    public void buildPreco() {
        violao.preco = 250;
    }

    @Override
    public void buildCor() {
        violao.cor = "Rosa";
    }

    @Override
    public void buildtipoTarraxa() {
        violao.tipoTarraxa = "Cromada";
    }

    @Override
    public void buildtipoCorda() {
        violao.tipoCorda = "Aço";
    }

    @Override
    public void buildtamBraco() {
        violao.tamBraco = 50;
    }

    @Override
    public void buildmatCorpo() {
        violao.matCorpo = "Jumbo\nO violão jumbo ficou famoso nas mãos de Elvis Presley.\nApesar de ser bem parecido com o tipo clássico, a grande diferença está em seu corpo mais largo e na base mais arredondada";
    }
    
}
