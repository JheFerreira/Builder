/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package violaobuilder;

/**
 *
 * @author Jéssica Ferreira
 */
public class DuploZeroBuilder extends ViolaoBuilder {

    @Override
    public void buildPreco() {
        violao.preco = 230;
    }

    @Override
    public void buildCor() {
        violao.cor = "Marron";
    }

    @Override
    public void buildtipoTarraxa() {
        violao.tipoTarraxa = "Cromada";
    }

    @Override
    public void buildtipoCorda() {
        violao.tipoCorda = "Nylon";
    }

    @Override
    public void buildtamBraco() {
        violao.tamBraco = 50;
    }

    @Override
    public void buildmatCorpo() {
        violao.matCorpo = "Duplo Zero\n são categorizados como Parlor, com estruturas menores e sendo mais indicado para uso casual e não tanto profissional\nEsse é um pouco maior, apresentando uma boa sonoridade e sendo indicado para técnicas de fingerstyle. ";  }

  
 
    
}
