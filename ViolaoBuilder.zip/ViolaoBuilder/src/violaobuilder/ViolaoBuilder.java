/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package violaobuilder;

/**
 *
 * @author Jéssica Ferreira
 */
public abstract class ViolaoBuilder {
    
   protected ViolaoProduto violao; 
    
   public ViolaoBuilder (){
       violao = new ViolaoProduto();
   }
    
        
   public abstract void  buildPreco();  
   public abstract void  buildCor();  
   public abstract void  buildtipoTarraxa();  
   public abstract void  buildtipoCorda();  
   public abstract void  buildtamBraco();  
   public abstract void  buildmatCorpo(); 
   
   public ViolaoProduto getViolao(){
       return violao;
   }

}
        