/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package violaobuilder;

/**
 *
 * @author Jéssica Ferreira
 */
public class Distribuidora {
    
    protected ViolaoBuilder matCorpo;
 
    public Distribuidora(ViolaoBuilder matCorpo) {
        this.matCorpo = matCorpo;
    }
 
    public void construirViolao() {
       matCorpo.buildPreco();
       matCorpo.buildCor();
       matCorpo.buildtipoCorda();
       matCorpo.buildtamBraco();
       matCorpo.buildtipoTarraxa();
       matCorpo.buildmatCorpo();
    }
 
    public ViolaoProduto getViolao() {
        return matCorpo.getViolao();
    }
    
}
