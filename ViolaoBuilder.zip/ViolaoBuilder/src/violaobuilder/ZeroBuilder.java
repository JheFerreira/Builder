/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package violaobuilder;

/**
 *
 * @author Jéssica Ferreira
 */
public class ZeroBuilder extends ViolaoBuilder {

    @Override
    public void buildPreco() {
        violao.preco = 300;
    }

    @Override
    public void buildCor() {
        violao.cor = "Marron";
    }

    @Override
    public void buildtipoTarraxa() {
        violao.tipoTarraxa = "Cromada";
    }

    @Override
    public void buildtipoCorda() {
        violao.tipoCorda = "Nylon";
    }

    @Override
    public void buildtamBraco() {
        violao.tamBraco = 50;
    }

    @Override
    public void buildmatCorpo() {
        violao.matCorpo = "Zero - Esses tipos de violões são categorizados como Parlor\nCom estruturas menores e sendo mais indicado para uso casual e não tanto profissional\nO violão zero é o menor, com uma estrutura confortável para tocar por bastante tempo.";
    }

    
}
