/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package violaobuilder;

/**
 *
 * @author Jéssica Ferreira
 */
public class ViolaoProduto {
    float preco;
    String cor;
    String tipoCorda;
    int tamBraco;
    String tipoTarraxa;
    String matCorpo;
    
    
    
}
